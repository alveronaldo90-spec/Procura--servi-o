# Procura Serviço — versão fácil de compilar

Projeto Android nativo em Kotlin, simplificado para depender apenas do Android SDK e do plugin Kotlin/Android.

## Para compilar pelo celular
Use um ambiente de build Android na nuvem que aceite projetos Gradle (por exemplo, um repositório Git com CI).

1. Extraia este ZIP.
2. Envie a pasta para um repositório Git.
3. Configure um workflow Android/Gradle.
4. Gere o APK em modo debug.
5. Baixe o APK gerado e instale no celular.

## Importante
Este ZIP é o projeto-fonte, não um APK. As oportunidades mostradas são demonstrativas e não são vagas reais.
