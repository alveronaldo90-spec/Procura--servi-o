package com.procuraservico.novocruzeiro

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup
import android.widget.*

data class Job(
    val title: String,
    val category: String,
    val pay: String,
    val location: String
)

class MainActivity : Activity() {
    private lateinit var container: LinearLayout

    private val jobs = listOf(
        Job("Ajudante de pedreiro", "Construção", "A combinar", "Novo Cruzeiro"),
        Job("Auxiliar de produção", "Produção", "A combinar", "Novo Cruzeiro"),
        Job("Serviços gerais", "Serviços", "Diária / combinar", "Novo Cruzeiro"),
        Job("Trabalho rural", "Rural", "A combinar", "Zona rural")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        container = findViewById(R.id.jobsContainer)

        findViewById<Button>(R.id.allButton).setOnClickListener { showJobs(jobs) }
        findViewById<Button>(R.id.constructionButton).setOnClickListener {
            showJobs(jobs.filter { it.category == "Construção" })
        }
        findViewById<Button>(R.id.farmButton).setOnClickListener {
            showJobs(jobs.filter { it.category == "Rural" })
        }
        findViewById<Button>(R.id.servicesButton).setOnClickListener {
            showJobs(jobs.filter { it.category == "Serviços" })
        }

        findViewById<EditText>(R.id.searchEditText).setOnEditorActionListener { v, _, _ ->
            val term = v.text.toString().trim()
            showJobs(if (term.isEmpty()) jobs else jobs.filter {
                "${it.title} ${it.category} ${it.location}".contains(term, true)
            })
            false
        }

        findViewById<Button>(R.id.postButton).setOnClickListener {
            Toast.makeText(this, "Cadastro de vagas será incluído na próxima versão.", Toast.LENGTH_LONG).show()
        }

        showJobs(jobs)
    }

    private fun showJobs(list: List<Job>) {
        container.removeAllViews()
        if (list.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "Nenhuma oportunidade encontrada."
                textSize = 16f
                setPadding(0, 24, 0, 24)
            })
            return
        }

        list.forEach { job ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(20, 18, 20, 18)
                background = GradientDrawable().apply {
                    setColor(Color.WHITE)
                    cornerRadius = 22f
                }
                elevation = 4f
            }

            card.addView(TextView(this).apply {
                text = job.title
                textSize = 19f
                setTextColor(Color.rgb(22, 101, 52))
                typeface = Typeface.DEFAULT_BOLD
            })
            card.addView(TextView(this).apply {
                text = "${job.category} • ${job.location}\nPagamento: ${job.pay}"
                textSize = 15f
                setTextColor(Color.DKGRAY)
                setPadding(0, 8, 0, 0)
            })
            card.addView(Button(this).apply {
                text = "Ver oportunidade"
                setOnClickListener {
                    Toast.makeText(
                        this@MainActivity,
                        "Vaga demonstrativa. A versão real terá contato do anunciante.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            })

            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(0, 14, 0, 0)
            container.addView(card, params)
        }
    }
}
